export CUDA_VISIBLE_DEVICES=3

model_name=TimeFilter

  python -u run.py \
    --task_name long_term_forecast \
    --is_training 2 \
    --root_path ./dataset/weather \
    --data_path weather.csv \
    --model_id weather_96_96 \
    --model TimeFilter \
    --data custom \
    --features M \
    --seq_len 96 \
    --label_len 48 \
    --pred_len 96 \
    --e_layers 2 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 21 \
    --dec_in 21 \
    --c_out 21 \
    --patch_len 48 \
    --des 'Exp' \
    --alpha_coef 0.85 \
    --beta_coef 0.15 \
    --d_model 128 \
    --d_ff 256 \
    --dropout 0.3 \
    --learning_rate 0.0005 \
    --batch_size 32 \
    --itr 1
mse:0.14812897145748138, mae:0.18757404386997223



  python -u run.py \
    --task_name long_term_forecast \
    --is_training 2 \
    --root_path ./dataset/weather \
    --data_path weather.csv \
    --model_id weather_96_192 \
    --model TimeFilter \
    --data custom \
    --features M \
    --seq_len 96 \
    --label_len 48 \
    --pred_len 192 \
    --e_layers 2 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 21 \
    --dec_in 21 \
    --c_out 21 \
    --patch_len 48 \
    --des 'Exp' \
    --alpha_coef 0.85 \
    --beta_coef 0.15 \
    --d_model 128 \
    --d_ff 256 \
    --dropout 0.3 \
    --learning_rate 0.0005 \
    --batch_size 32 \
    --itr 1

mse:0.1990358829498291, mae:0.23640216886997223

  python -u run.py \
    --task_name long_term_forecast \
    --is_training 2 \
    --root_path ./dataset/weather \
    --data_path weather.csv \
    --model_id weather_96_336 \
    --model TimeFilter \
    --data custom \
    --features M \
    --seq_len 96 \
    --label_len 48 \
    --pred_len 336 \
    --e_layers 2 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 21 \
    --dec_in 21 \
    --c_out 21 \
    --patch_len 48 \
    --des 'Exp' \
    --alpha_coef 0.85 \
    --beta_coef 0.15 \
    --d_model 128 \
    --d_ff 256 \
    --dropout 0.3 \
    --learning_rate 0.0005 \
    --batch_size 32 \
    --itr 1

mse:0.2561478018760681, mae:0.2794291377067566



  python -u run.py \
    --task_name long_term_forecast \
    --is_training 2 \
    --root_path ./dataset/weather \
    --data_path weather.csv \
    --model_id weather_96_720 \
    --model TimeFilter \
    --data custom \
    --features M \
    --seq_len 96 \
    --label_len 48 \
    --pred_len 720 \
    --e_layers 2 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 21 \
    --dec_in 21 \
    --c_out 21 \
    --patch_len 48 \
    --des 'Exp' \
    --alpha_coef 0.85 \
    --beta_coef 0.15 \
    --d_model 128 \
    --d_ff 256 \
    --dropout 0.3 \
    --learning_rate 0.0005 \
    --batch_size 32 \
    --itr 1
mse:0.33982908725738525, mae:0.3335687816143036



    