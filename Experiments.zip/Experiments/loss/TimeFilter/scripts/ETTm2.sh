export CUDA_VISIBLE_DEVICES=4

model_name=TimeFilter
seq_len=96


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_96 \
  --model TimeFilter \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.6 \
  --top_p 0.0 \
  --patch_len 16 \
  --des 'Exp' \
  --alpha_coef 0.5 \
  --beta_coef 0.5 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 128 \
  --d_ff 128 \
  --itr 1

mse:0.1673683524131775, mae:0.2510657012462616




python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_192 \
  --model TimeFilter \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.6 \
  --top_p 0.0 \
  --patch_len 16 \
  --des 'Exp' \
  --alpha_coef 0.5 \
  --beta_coef 0.5 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 128 \
  --d_ff 128 \
  --itr 1
  
mse:0.23290789127349854, mae:0.2943871021270752  
  
  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_336 \
  --model TimeFilter \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.6 \
  --top_p 0.0 \
  --patch_len 16 \
  --des 'Exp' \
  --alpha_coef 0.5 \
  --beta_coef 0.5 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 128 \
  --d_ff 128 \
  --itr 1
mse:0.2906787395477295, mae:0.3319561779499054  
  
  


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm2.csv \
  --model_id ETTm2_96_720 \
  --model TimeFilter \
  --data ETTm2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.8 \
  --top_p 0.0 \
  --patch_len 16 \
  --des 'Exp' \
  --alpha_coef 0.5 \
  --beta_coef 0.5 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 128 \
  --d_ff 128 \
  --itr 1
mse:0.3889552056789398, mae:0.3901991844177246
