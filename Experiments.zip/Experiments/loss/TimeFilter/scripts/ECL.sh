export CUDA_VISIBLE_DEVICES=5

model_name=TimeFilter


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/electricity \
  --data_path electricity.csv \
  --model_id ECL_96_96 \
  --model TimeFilter \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --patch_len 32 \
  --des 'Exp' \
  --alpha_coef 0.75 \
  --beta_coef 0.25 \
  --learning_rate 0.001 \
  --batch_size 16 \
  --train_epochs 15 \
  --d_model 512\
  --d_ff 512\
  --dropout 0.5 \
  --itr 1
mse:0.13316188752651215, mae:0.22533364593982697  



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/electricity \
  --data_path electricity.csv \
  --model_id ECL_96_96 \
  --model TimeFilter \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --patch_len 32 \
  --des 'Exp' \
  --alpha_coef 0.5 \
  --beta_coef 0.5 \
  --learning_rate 0.001 \
  --batch_size 16 \
  --train_epochs 15 \
  --d_model 512\
  --d_ff 512\
  --dropout 0.4 \
  --itr 1

mse:0.15539295971393585, mae:0.2466852068901062



  

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/electricity \
  --data_path electricity.csv \
  --model_id ECL_96_96 \
  --model TimeFilter \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --patch_len 32 \
  --des 'Exp' \
  --alpha_coef 0.75 \
  --beta_coef 0.25 \
  --learning_rate 0.001 \
  --batch_size 16 \
  --train_epochs 15 \
  --d_model 512\
  --d_ff 512\
  --dropout 0.4 \
  --itr 1

mse:0.1634594202041626, mae:0.2544648349285126



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/electricity \
  --data_path electricity.csv \
  --model_id ECL_96_96 \
  --model TimeFilter \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --patch_len 32 \
  --des 'Exp' \
  --alpha_coef 0.75 \
  --beta_coef 0.25 \
  --learning_rate 0.001 \
  --batch_size 16 \
  --train_epochs 15 \
  --d_model 512\
  --d_ff 512\
  --dropout 0.4 \
  --itr 1


mse:0.18367831408977509, mae:0.27695024013519287
