export CUDA_VISIBLE_DEVICES=7

model_name=TimeFilter
seq_len=96


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_96 \
  --model TimeFilter \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --patch_len 4 \
  --dropout 0.8 \
  --top_p 0.0 \
  --des 'Exp' \
  --alpha_coef 0.75 \
  --beta_coef 0.25 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 128 \
  --d_ff 256 \
  --itr 1
mse:0.2823648452758789, mae:0.3321724236011505




python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_96 \
  --model TimeFilter \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --patch_len 4 \
  --dropout 0.6 \
  --alpha 0.8 \
  --des 'Exp' \
  --alpha_coef 0.75 \
  --beta_coef 0.25 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 128 \
  --d_ff 256 \
  --itr 1

mse:0.36236998438835144, mae:0.38595348596572876

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_336 \
  --model TimeFilter \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --patch_len 8 \
  --alpha 0.4 \
  --dropout 0.7 \
  --top_p 0.0 \
  --des 'Exp' \
  --alpha_coef 0.75 \
  --beta_coef 0.25 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 256 \
  --d_ff 256 \
  --itr 1

mse:0.4044521450996399, mae:0.4211761951446533



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh2.csv \
  --model_id ETTh2_96_720 \
  --model TimeFilter \
  --data ETTh2 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --patch_len 8 \
  --alpha 0.9 \
  --dropout 0.3 \
  --top_p 0.0 \
  --des 'Exp' \
  --alpha_coef 0.75 \
  --beta_coef 0.25 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 256 \
  --d_ff 256 \
  --itr 1

mse:0.4008118808269501, mae:0.42596620321273804


  
  