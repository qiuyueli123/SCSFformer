export CUDA_VISIBLE_DEVICES=3


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_96 \
  --model TimeFilter \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.8 \
  --patch_len 2 \
  --pos 0 \
  --des 'Exp' \
  --alpha_coef 0.75 \
  --beta_coef 0.25 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 16 \
  --d_model 128 \
  --d_ff 256 \
  --itr 1
mse:0.3700048625469208, mae:0.3862312436103821


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_192 \
  --model TimeFilter \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.8 \
  --patch_len 2 \
  --pos 0 \
  --des 'Exp' \
  --alpha_coef 0.5 \
  --beta_coef 0.5 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 16 \
  --d_model 128 \
  --d_ff 256 \
  --itr 1

mse:0.4123745560646057, mae:0.4170060455799103



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_336 \
  --model TimeFilter \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.8 \
  --patch_len 2 \
  --pos 0 \
  --des 'Exp' \
  --alpha_coef 0.25 \
  --beta_coef 0.75 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 11 \
  --d_model 128 \
  --d_ff 256 \
  --itr 1
  
mse:0.4493328034877777, mae:0.4382275640964508  



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh1.csv \
  --model_id ETTh1_96_720 \
  --model TimeFilter \
  --data ETTh1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.8 \
  --patch_len 2 \
  --pos 0 \
  --des 'Exp' \
  --alpha_coef 0.5 \
  --beta_coef 0.5 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 11 \
  --d_model 128 \
  --d_ff 128 \
  --itr 1

mse:0.4454224705696106, mae:0.4516949951648712