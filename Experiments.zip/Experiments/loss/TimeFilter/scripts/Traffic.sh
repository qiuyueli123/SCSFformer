
model_name=TimeFilter


  python -u run.py \
    --task_name long_term_forecast \
    --is_training 1 \
    --root_path ./dataset/traffic \
    --data_path traffic.csv \
    --model_id traffic_96_96 \
    --model TimeFilter \
    --data custom \
    --features M \
    --seq_len 96 \
    --label_len 48 \
    --pred_len 96 \
    --e_layers 3 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 862 \
    --dec_in 862 \
    --c_out 862 \
    --patch_len 96 \
    --des 'Exp' \
    --alpha_coef 0.5 \
    --beta_coef 0.5 \
    --d_model 512 \
    --d_ff 2048 \
    --dropout 0.3 \
    --top_p 0.0 \
    --pos 0 \
    --learning_rate 0.001 \
    --batch_size 16 \
    --train_epochs 30 \
    --itr 1
mse:0.37276163697242737, mae:0.23795966804027557

  python -u run.py \
    --task_name long_term_forecast \
    --is_training 1 \
    --root_path ./dataset/traffic \
    --data_path traffic.csv \
    --model_id traffic_96_96 \
    --model TimeFilter \
    --data custom \
    --features M \
    --seq_len 96 \
    --label_len 48 \
    --pred_len 192 \
    --e_layers 3 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 862 \
    --dec_in 862 \
    --c_out 862 \
    --patch_len 96 \
    --des 'Exp' \
    --alpha_coef 0.5 \
    --beta_coef 0.5 \
    --d_model 512 \
    --d_ff 2048 \
    --dropout 0.3 \
    --top_p 0.0 \
    --pos 0 \
    --learning_rate 0.001 \
    --batch_size 16 \
    --train_epochs 30 \
    --itr 1
mse:0.3935701251029968, mae:0.24826298654079437


  python -u run.py \
    --task_name long_term_forecast \
    --is_training 1 \
    --root_path ./dataset/traffic \
    --data_path traffic.csv \
    --model_id traffic_96_96 \
    --model TimeFilter \
    --data custom \
    --features M \
    --seq_len 96 \
    --label_len 48 \
    --pred_len 336 \
    --e_layers 3 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 862 \
    --dec_in 862 \
    --c_out 862 \
    --patch_len 96 \
    --des 'Exp' \
    --alpha_coef 0.5 \
    --beta_coef 0.5 \
    --d_model 512 \
    --d_ff 2048 \
    --dropout 0.3 \
    --top_p 0.0 \
    --pos 0 \
    --learning_rate 0.001 \
    --batch_size 16 \
    --train_epochs 30 \
    --itr 1
mse:0.41244015097618103, mae:0.25649595260620117


  python -u run.py \
    --task_name long_term_forecast \
    --is_training 1 \
    --root_path ./dataset/traffic \
    --data_path traffic.csv \
    --model_id traffic_96_96 \
    --model TimeFilter \
    --data custom \
    --features M \
    --seq_len 96 \
    --label_len 48 \
    --pred_len 720 \
    --e_layers 3 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 862 \
    --dec_in 862 \
    --c_out 862 \
    --patch_len 96 \
    --des 'Exp' \
    --alpha_coef 0.5 \
    --beta_coef 0.5 \
    --d_model 512 \
    --d_ff 2048 \
    --dropout 0.3 \
    --top_p 0.0 \
    --pos 0 \
    --learning_rate 0.001 \
    --batch_size 16 \
    --train_epochs 30 \
    --itr 1
mse:0.4436163008213043, mae:0.27492326498031616
