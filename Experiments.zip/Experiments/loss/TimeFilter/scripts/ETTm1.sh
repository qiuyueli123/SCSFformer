export CUDA_VISIBLE_DEVICES=1

model_name=TimeFilter



python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_96 \
  --model TimeFilter \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 96\
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.3 \
  --top_p 0.0 \
  --patch_len 8 \
  --des 'Exp' \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 256 \
  --d_ff 256 \
  --itr 1

mse:0.31082841753959656, mae:0.34742099046707153

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_192 \
  --model TimeFilter \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.5 \
  --top_p 0.0 \
  --patch_len 8 \
  --des 'Exp' \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 256 \
  --d_ff 256 \
  --itr 1
mse:0.35371941328048706, mae:0.3718922734260559

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_336 \
  --model TimeFilter \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.5 \
  --top_p 0.0 \
  --patch_len 8 \
  --des 'Exp' \
  --alpha_coef 0.5 \
  --beta_coef 0.5 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 256 \
  --d_ff 256 \
  --itr 1

mse:0.38236477971076965, mae:0.3943704664707184


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm1.csv \
  --model_id ETTm1_96_96 \
  --model TimeFilter \
  --data ETTm1 \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.7 \
  --top_p 0.0 \
  --patch_len 16 \
  --des 'Exp' \
  --alpha_coef 0.5 \
  --beta_coef 0.5 \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --d_model 256 \
  --d_ff 256 \
  --itr 1

mse:0.45302197337150574, mae:0.4318317174911499