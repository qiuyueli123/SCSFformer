export CUDA_VISIBLE_DEVICES=7

model_name=TimeFilter
seq_len=96

for pred_len in 96
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh2.csv \
  --model_id ETTh2_$seq_len'_'$pred_len \
  --model $model_name \
  --data ETTh2 \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 1 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --patch_len 4 \
  --dropout 0.8 \
  --top_p 0.0 \
  --des 'Exp' \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 10 \
  --w_lin 100 \
  --d_model 128 \
  --d_ff 256 \
  --itr 1
done

mse:0.2832484543323517, mae:0.33717912435531616


for pred_len in 192
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh2.csv \
  --model_id ETTh2_$seq_len'_'$pred_len \
  --model $model_name \
  --data ETTh2 \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --patch_len 8 \
  --alpha 0.4 \
  --dropout 0.1 \
  --top_p 0.0 \
  --des 'Exp' \
  --learning_rate 0.00006 \
  --batch_size 32 \
  --train_epochs 9 \
  --d_model 256 \
  --d_ff 360 \
  --w_lin 4 \
  --lradj type3\
  --itr 1
done

mse:0.35378095507621765, mae:0.39101555943489075




for pred_len in 336
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh2.csv \
  --model_id ETTh2_$seq_len'_'$pred_len \
  --model $model_name \
  --data ETTh2 \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --patch_len 8 \
  --alpha 0.4 \
  --dropout 0.1 \
  --top_p 0.0 \
  --des 'Exp' \
  --learning_rate 0.00006 \
  --batch_size 32 \
  --train_epochs 12 \
  --d_model 256 \
  --d_ff 256 \
  --w_lin 4 \
  --lradj type3\
  --itr 1
done
mse:0.3970228135585785, mae:0.42320990562438965

for pred_len in 720
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTh2.csv \
  --model_id ETTh2_$seq_len'_'$pred_len \
  --model $model_name \
  --data ETTh2 \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --patch_len 8 \
  --alpha 0.9 \
  --dropout 0.5 \
  --top_p 0.0 \
  --des 'Exp' \
  --learning_rate 0.00009 \
  --batch_size 32 \
  --train_epochs 8 \
  --d_model 256 \
  --d_ff 256 \
  --w_lin 3.5 \
  --lradj type3 \
  --itr 1
done
mse:0.3963571786880493, mae:0.4324548542499542

