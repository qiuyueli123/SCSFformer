export CUDA_VISIBLE_DEVICES=5

model_name=TimeFilter

# 96


seq_len=96
for pred_len in 96
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/electricity \
  --data_path electricity.csv \
  --model_id ECL_$seq_len'_'$pred_len \
  --model $model_name \
  --data custom \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --patch_len 32 \
  --des 'Exp' \
  --learning_rate 0.00075 \
  --batch_size 16 \
  --train_epochs 20 \
  --w_lin 1000 \
  --d_model 1024\
  --d_ff 1024\
  --dropout 0.5 \
  --itr 1
done

mse:0.1331939995288849, mae:0.22905318439006805



for pred_len in 192
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/electricity \
  --data_path electricity.csv \
  --model_id ECL_$seq_len'_'$pred_len \
  --model $model_name \
  --data custom \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --patch_len 32 \
  --des 'Exp' \
  --learning_rate 0.00075 \
  --batch_size 16 \
  --train_epochs 25 \
  --w_lin 1000 \
  --d_model 512\
  --d_ff 512\
  --dropout 0.5 \
  --itr 1
done
mse:0.15129204094409943, mae:0.24664448201656342


for pred_len in 336
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/electricity \
  --data_path electricity.csv \
  --model_id ECL_$seq_len'_'$pred_len \
  --model $model_name \
  --data custom \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --patch_len 16 \
  --des 'Exp' \
  --learning_rate 0.001 \
  --batch_size 16 \
  --train_epochs 20 \
  --w_lin 1000 \
  --d_model 512\
  --d_ff 512\
  --dropout 0.4 \
  --itr 1
done
mse:0.15859706699848175, mae:0.2591007649898529


for pred_len in 720
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/electricity \
  --data_path electricity.csv \
  --model_id ECL_$seq_len'_'$pred_len \
  --model $model_name \
  --data custom \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 321 \
  --dec_in 321 \
  --c_out 321 \
  --patch_len 32 \
  --des 'Exp' \
  --learning_rate 0.001 \
  --batch_size 16 \
  --train_epochs 15 \
  --w_lin 1000 \
  --d_model 512\
  --d_ff 512\
  --dropout 0.4 \
  --itr 1
done

mse:0.1826414316892624, mae:0.2818327844142914
