export CUDA_VISIBLE_DEVICES=3

model_name=TimeFilter

# 96
seq_len=96


for pred_len in 96
do
  python -u run.py \
    --task_name long_term_forecast \
    --is_training 2 \
    --root_path ./dataset/weather \
    --data_path weather.csv \
    --model_id weather_$seq_len'_'$pred_len \
    --model $model_name \
    --data custom \
    --features M \
    --seq_len $seq_len \
    --label_len 48 \
    --pred_len $pred_len \
    --e_layers 2 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 21 \
    --dec_in 21 \
    --c_out 21 \
    --patch_len 48 \
    --des 'Exp' \
    --d_model 128 \
    --d_ff 256 \
    --dropout 0.3 \
    --learning_rate 0.0005 \
    --train_epochs 16 \
    --batch_size 32 \
    --w_lin 100 \
    --itr 1
done
mse:0.15220263600349426, mae:0.19924291968345642


for pred_len in 192
do
  python -u run.py \
    --task_name long_term_forecast \
    --is_training 2 \
    --root_path ./dataset/weather \
    --data_path weather.csv \
    --model_id weather_$seq_len'_'$pred_len \
    --model $model_name \
    --data custom \
    --features M \
    --seq_len $seq_len \
    --label_len 48 \
    --pred_len $pred_len \
    --e_layers 2 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 21 \
    --dec_in 21 \
    --c_out 21 \
    --patch_len 48 \
    --des 'Exp' \
    --d_model 128 \
    --d_ff 256 \
    --dropout 0.3 \
    --learning_rate 0.0005 \
    --train_epochs 12 \
    --batch_size 32 \
    --w_lin 75 \
    --itr 1
done
mse:0.1994783580303192, mae:0.2454494833946228


for pred_len in 336
do
  python -u run.py \
    --task_name long_term_forecast \
    --is_training 2 \
    --root_path ./dataset/weather \
    --data_path weather.csv \
    --model_id weather_$seq_len'_'$pred_len \
    --model $model_name \
    --data custom \
    --features M \
    --seq_len $seq_len \
    --label_len 48 \
    --pred_len $pred_len \
    --e_layers 2 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 21 \
    --dec_in 21 \
    --c_out 21 \
    --patch_len 48 \
    --des 'Exp' \
    --d_model 128 \
    --d_ff 256 \
    --dropout 0.3 \
    --learning_rate 0.0005 \
    --train_epochs 16 \
    --batch_size 32 \
    --w_lin 75 \
    --itr 1
done
mse:0.2539949119091034, mae:0.286761999130249


for pred_len in 720
do
  python -u run.py \
    --task_name long_term_forecast \
    --is_training 2 \
    --root_path ./dataset/weather \
    --data_path weather.csv \
    --model_id weather_$seq_len'_'$pred_len \
    --model $model_name \
    --data custom \
    --features M \
    --seq_len $seq_len \
    --label_len 48 \
    --pred_len $pred_len \
    --e_layers 2 \
    --d_layers 1 \
    --factor 3 \
    --enc_in 21 \
    --dec_in 21 \
    --c_out 21 \
    --patch_len 48 \
    --des 'Exp' \
    --d_model 256 \
    --d_ff 256 \
    --dropout 0.3 \
    --learning_rate 0.0003 \
    --batch_size 64 \
    --train_epochs 1 \
    --w_lin 1 \
    --lradj type3\
    --itr 1
done
mse:0.3284757137298584, mae:0.33906814455986023


