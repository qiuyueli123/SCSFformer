export CUDA_VISIBLE_DEVICES=1

model_name=TimeFilter
seq_len=96



for pred_len in 96
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm1.csv \
  --model_id ETTm1_$seq_len'_'$pred_len \
  --model $model_name \
  --data ETTm1 \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.3 \
  --top_p 0.0 \
  --patch_len 8 \
  --des 'Exp' \
  --learning_rate 0.00015 \
  --batch_size 32 \
  --train_epochs 13 \
  --d_model 256 \
  --d_ff 256 \
  --w_lin 30 \
  --lradj type3\
  --itr 1
done
mse:0.3042471408843994, mae:0.3515988290309906


for pred_len in 192
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm1.csv \
  --model_id ETTm1_$seq_len'_'$pred_len \
  --model $model_name \
  --data ETTm1 \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.6 \
  --top_p 0.0 \
  --patch_len 8 \
  --des 'Exp' \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 12 \
  --d_model 256 \
  --d_ff 256 \
  --w_lin 5 \
  --lradj type3\
  --itr 1
done
mse:0.34999123215675354, mae:0.37634003162384033





for pred_len in 336
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm1.csv \
  --model_id ETTm1_$seq_len'_'$pred_len \
  --model $model_name \
  --data ETTm1 \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.6 \
  --top_p 0.0 \
  --patch_len 8 \
  --des 'Exp' \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 12 \
  --d_model 256 \
  --d_ff 256 \
  --w_lin 2 \
  --lradj type3\
  --itr 1
done

mse:0.3784818649291992, mae:0.40014535188674927





for pred_len in 720
do
python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small \
  --data_path ETTm1.csv \
  --model_id ETTm1_$seq_len'_'$pred_len \
  --model $model_name \
  --data ETTm1 \
  --features M \
  --seq_len $seq_len \
  --label_len 48 \
  --pred_len $pred_len \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 7 \
  --dec_in 7 \
  --c_out 7 \
  --dropout 0.5 \
  --top_p 0.0 \
  --patch_len 16 \
  --des 'Exp' \
  --learning_rate 0.0001 \
  --batch_size 32 \
  --train_epochs 9 \
  --d_model 256 \
  --d_ff 256 \
  --w_lin 2 \
  --lradj type3\
  --itr 1
done
mse:0.43972355127334595, mae:0.43403348326683044
